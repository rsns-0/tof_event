# """
# WIP
# WIP
# WIP
# """

# from dataclasses import dataclass
# from pandas import DataFrame

# @dataclass
# class UiDataCoordinatesOnly:
#     name: str
#     coordinates: tuple[int]

# @dataclass
# class UiDataImage():
#     name:str
#     file_name: str
#     region: tuple[int,int,int,int]